const entrada = require("readline-sync");
const {
    calcularMaoDeObra,
    calcularTotal,
    verificarDesconto
} = require("./funcoesOrcamento");

const cliente = entrada.question("Nome do cliente: ");
const valorMateriais = entrada.questionFloat("Valor dos materiais: R\$ ");
const horas = entrada.questionFloat("Horas de servico: ");

const maoDeObra = calcularMaoDeObra(horas);
const total = calcularTotal(valorMateriais, horas);
const situacaoDesconto = verificarDesconto(total);


console.log("\n=== RELATÓRIO DE ORÇAMENTO ===");
console.log(`Cliente: ${cliente}`);
console.log(`Materiais: R$ ${valorMateriais.toFixed(2)}`);
console.log(`Mão de obra: R$ ${maoDeObra.toFixed(2)}`);
console.log(`Total: R$ ${total.toFixed(2)}`);
console.log(`Situação: ${situacaoDesconto}`);
