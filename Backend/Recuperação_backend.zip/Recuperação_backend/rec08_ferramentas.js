const entrada = require("readline-sync");

const ferramentas = [];


for (let i = 0; i < 4; i++) {
    console.log(`\nCadastro da ferramenta ${i + 1}:`);

    const nome = entrada.question("Nome: ");
    const quantidade = entrada.questionInt("Quantidade: ");
    const minimo = entrada.questionInt("Quantidade minima: ");


    const ferramenta = {
        nome,
        quantidade,
        minimo
    };


    ferramentas.push(ferramenta);
}

console.log("\n===RELATORIO===")

for (let i = 0; i < ferramentas.length; i++) {
    const item = ferramentas[i];


    let situacao;
    if (item.quantidade < item.minimo) {
        situacao = "REPOR";
    } else {
        situacao = "ESTOQUE SUFICIENTE";
    }


    console.log(`\nFerramenta: ${item.nome}`);
    console.log(`Quantidade: ${item.quantidade}`);
    console.log(`Mínimo: ${item.minimo}`);
    console.log(`Situação: ${situacao}`);
}
