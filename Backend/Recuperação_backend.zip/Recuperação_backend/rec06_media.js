const entrada = require('readline-sync');

let tempoTotal = 0;

for (let inspecao = 1; inspecao <= 6; inspecao++){

    const tempoInspecao = entrada.questionFloat(`Digite o tempo da ${inspecao} inspecao: `);
    tempoTotal += tempoInspecao;
}

const tempoMedio = tempoTotal / 6;

console.log(`Tempo total: ${tempoTotal.toFixed(2)}`);
console.log(`Tempo médio: ${tempoMedio.toFixed(2)}`);
