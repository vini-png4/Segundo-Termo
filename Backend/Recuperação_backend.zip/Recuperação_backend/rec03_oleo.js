
const entrada = require(`readline-sync`);

const temperatura = entrada.questionFloat("Digite a temperatura: ");


if (temperatura >= 40 && temperatura <=80) {
    console.log("NÍVEL NORMAL");
}else {
    console.log("INSPEÇÃO NECESSÁRIA");
}

console.log(`Temperatura: ${temperatura}`);
