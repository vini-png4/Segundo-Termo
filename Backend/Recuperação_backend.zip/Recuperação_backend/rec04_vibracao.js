const entrada = require("readline-sync");


const vibracao = entrada.questionFloat("Digite a vibracao do equipamento (mm/s): ");

let situacao = "";


if (vibracao <= 3) {
    situacao = "ESTAVEL";
} else if (vibracao <= 6) { 
    situacao = "ATENCAO";
} else {
    situacao = "CRITICA";
}

console.log(`\nValor informado: ${vibracao} mm/s`);
console.log(`SITUAÇÃO: ${situacao}`);
