const entrada = require("readline-sync");

function calcularAproveitamento(util, total) {
    return (util / total) * 100;
}

function classificarAproveitamento(percentual) {
    if (percentual >= 90) {
        return "EXCELENTE";
    } else if (percentual >= 75 && percentual <= 89.99) {
        return "ADEQUADO";
    } else {
        return "REVISAR PROCESSO";
    }
}

const quantidadeTotal = entrada.questionFloat("Digite a quantidade total de materia-prima: ");
const quantidadeUtil = entrada.questionFloat("Digite a quantidade util de materia-prima:: ");

const percentual = calcularAproveitamento(quantidadeUtil, quantidadeTotal);
const classificacao = classificarAproveitamento(percentual);

console.log("\n=== RELATÓRIO DE APROVEITAMENTO ===");

console.log(`Quantidade Total: ${quantidadeTotal}`);
console.log(`Quantidade Útil: ${quantidadeUtil}`);
console.log(`Percentual de Aproveitamento: ${percentual.toFixed(2)}%`);
console.log(`Classificação: ${classificacao}`);
