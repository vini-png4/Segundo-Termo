const entrada = require(`readline-sync`);

const qtdPorHora = entrada.questionInt("Digite a quantidade de caixas produzida por hora: ");
const HorasTrabalhadas = entrada.questionInt("Digite as horas trabalhadas: ");

const total = qtdPorHora * HorasTrabalhadas

console.log(`\n=== Relatorio de Producao ===`);

console.log(`Producao por Hora: ${qtdPorHora}`);
console.log(`Horas trabalhadas: ${HorasTrabalhadas}`);
console.log(`Total de caixas produzidas: ${total}`);