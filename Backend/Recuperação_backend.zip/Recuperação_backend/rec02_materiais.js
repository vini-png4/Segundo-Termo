const entrada = require(`readline-sync`);

const nomeMaterial = entrada.question("Digite o nome do produto: ");
const quantidade = entrada.question("Digite a quantidade desejada: ");
const precoUnitario = entrada.questionFloat("Digite o preco unitario: ");

const total = precoUnitario * quantidade;

console.log(`Material: ${nomeMaterial}`);
console.log(`Quantidade: ${quantidade} `);
console.log(`Preco Unitario do produto: ${precoUnitario}`);
console.log(`Total a pagar: ${total.toFixed(2)}`);